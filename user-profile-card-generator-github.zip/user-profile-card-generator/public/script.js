const form = document.getElementById("profileForm");
const bioInput = document.getElementById("bio");
const statusText = document.getElementById("status");
const grid = document.getElementById("profilesGrid");
const count = document.getElementById("profileCount");
const createButton = document.getElementById("createButton");

bioInput.addEventListener("input", () => {
  document.getElementById("bioCount").textContent = `${bioInput.value.length} / 500`;
});

function showStatus(text, error = false) {
  statusText.textContent = text;
  statusText.classList.toggle("error", error);
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2)
    .map(part => part[0].toUpperCase()).join("");
}

function makeCard(profile) {
  const card = document.createElement("article");
  card.className = "profile-card";
  const banner = document.createElement("div");
  banner.className = "card-banner";
  const body = document.createElement("div");
  body.className = "card-body";
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = initials(profile.name);
  const name = document.createElement("h3");
  name.textContent = profile.name;
  const bio = document.createElement("p");
  bio.className = "profile-bio";
  bio.textContent = profile.bio;
  body.append(avatar, name, bio);

  if (profile.skills.length) {
    const skills = document.createElement("div");
    skills.className = "skills";
    profile.skills.forEach(skill => {
      const chip = document.createElement("span");
      chip.className = "skill-chip";
      chip.textContent = skill;
      skills.appendChild(chip);
    });
    body.appendChild(skills);
  }

  const links = document.createElement("div");
  links.className = "social-links";
  for (const [label, url] of Object.entries(profile.socialLinks || {})) {
    if (!url) continue;
    try {
      const parsed = new URL(url);
      if (!["http:", "https:"].includes(parsed.protocol)) continue;
      const link = document.createElement("a");
      link.href = parsed.href;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = label === "github" ? "GitHub ↗" : "LinkedIn ↗";
      links.appendChild(link);
    } catch {}
  }
  if (links.childElementCount) body.appendChild(links);

  const date = document.createElement("p");
  date.className = "created-at";
  date.textContent = `Created ${new Date(profile.createdAt).toLocaleDateString()}`;
  body.appendChild(date);
  card.append(banner, body);
  return card;
}

async function loadProfiles() {
  try {
    const profiles = await api("/api/profiles");
    grid.replaceChildren();
    count.textContent = `${profiles.length} ${profiles.length === 1 ? "profile" : "profiles"}`;
    if (!profiles.length) {
      const empty = document.createElement("p");
      empty.className = "empty-state";
      empty.textContent = "No profiles yet. Create your first one using the form above.";
      grid.appendChild(empty);
      return;
    }
    profiles.forEach(profile => grid.appendChild(makeCard(profile)));
  } catch (error) {
    showStatus(error.message, true);
    grid.replaceChildren();
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "Could not load profiles. Please refresh the page.";
    grid.appendChild(empty);
  }
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(form).entries());
  createButton.disabled = true;
  createButton.textContent = "Creating profile...";
  try {
    await api("/api/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    form.reset();
    document.getElementById("bioCount").textContent = "0 / 500";
    showStatus("Your profile card has been created and saved.");
    await loadProfiles();
  } catch (error) {
    showStatus(error.message, true);
  } finally {
    createButton.disabled = false;
    createButton.textContent = "Create my profile ↗";
  }
});

loadProfiles();
