# User Profile Card Generator

A full-stack web app that collects a name, bio, skills, and social links; processes the input on a Node.js/Express server; stores profile records in SQLite; and renders dynamic profile cards.

## Tech stack
- HTML, CSS, vanilla JavaScript
- Node.js and Express
- SQLite (`better-sqlite3`)

## Run locally
1. Install Node.js (LTS).
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Open http://localhost:3000.

The `profiles.db` database is created automatically on first run and excluded from Git.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/profiles` | List saved profiles |
| POST | `/api/profiles` | Validate and save a profile |

Skills are entered as comma-separated values. Social links must be HTTP/HTTPS URLs. The app uses parameterized SQL and DOM `textContent` for safer handling of user input.

## Future improvements
- Edit and delete profiles
- Add profile photos
- Add authentication and per-user profiles
- Add search and pagination
