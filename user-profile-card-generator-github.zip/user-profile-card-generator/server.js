const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "profiles.db"));

db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    bio TEXT NOT NULL,
    skills TEXT NOT NULL,
    github TEXT NOT NULL DEFAULT '',
    linkedin TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
  )
`);

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

function cleanText(value, max) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function safeUrl(value) {
  const text = cleanText(value, 300);
  if (!text) return "";
  try {
    const url = new URL(text);
    return ["http:", "https:"].includes(url.protocol) ? url.href : "";
  } catch { return ""; }
}
function toProfile(row) {
  return {
    id: row.id, name: row.name, bio: row.bio,
    skills: JSON.parse(row.skills),
    socialLinks: { github: row.github, linkedin: row.linkedin },
    createdAt: row.created_at
  };
}

const getAll = db.prepare("SELECT * FROM profiles ORDER BY id DESC");
const insert = db.prepare(`
  INSERT INTO profiles (name, bio, skills, github, linkedin, created_at)
  VALUES (@name, @bio, @skills, @github, @linkedin, @created_at)
`);

app.get("/api/profiles", (req, res) => {
  try { res.json(getAll.all().map(toProfile)); }
  catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not load profiles." });
  }
});

app.post("/api/profiles", (req, res) => {
  try {
    const name = cleanText(req.body.name, 80);
    const bio = cleanText(req.body.bio, 500);
    const rawSkills = Array.isArray(req.body.skills)
      ? req.body.skills.join(",") : cleanText(req.body.skills, 500);
    const skills = [...new Set(rawSkills.split(",")
      .map(s => s.trim().replace(/\s+/g, " "))
      .filter(Boolean).map(s => s.slice(0, 40)))].slice(0, 12);

    if (name.length < 2 || !bio) {
      return res.status(400).json({ error: "Enter a name (at least 2 characters) and a bio." });
    }

    const result = insert.run({
      name, bio, skills: JSON.stringify(skills),
      github: safeUrl(req.body.github),
      linkedin: safeUrl(req.body.linkedin),
      created_at: new Date().toISOString()
    });
    const row = db.prepare("SELECT * FROM profiles WHERE id = ?").get(result.lastInsertRowid);
    res.status(201).json(toProfile(row));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not create profile." });
  }
});

app.listen(PORT, () => console.log(`Profile Card Generator running at http://localhost:${PORT}`));
process.on("SIGINT", () => { db.close(); process.exit(0); });
process.on("SIGTERM", () => { db.close(); process.exit(0); });
