# LaunchPath — Platform Onboarding and Offer Letter Acceptance

A beginner-friendly full-stack project that demonstrates candidate registration, offer review, offer acceptance/decline, and a simple admin overview.

> **Demo only:** The company and offer information in this project are sample data. This is not a real employment offer or a production HR system.

## Features

- Candidate registration form with basic server-side validation
- SQLite database for candidates and offers
- Automatic demo offer creation after registration
- Accept or decline a pending offer
- Prevent changing an offer after a response has been recorded
- Dashboard counters and candidate directory
- Responsive layout for desktop and mobile

## Technology stack

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js and Express
- Database: SQLite (`sqlite3`)
- Version control / submission: Git and GitHub

## Requirements

Install Node.js (LTS) from https://nodejs.org/ and Git from https://git-scm.com/ (Git is optional if you upload using GitHub's website).

## Run locally

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open http://localhost:3000 in your browser.

A sample candidate and sample offer are added automatically to a new database so you can test the interface. Register another candidate to test the onboarding form. The SQLite database file is generated locally and is intentionally excluded from Git.

## API endpoints

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Check whether the server is running |
| GET | `/api/candidates` | List candidates and offer details |
| POST | `/api/candidates` | Register a candidate and create a demo offer |
| PATCH | `/api/offers/:id/respond` | Accept or decline a pending offer |

## Project structure

```text
platform-onboarding-offer-acceptance/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Database design

**candidates** stores the candidate's name, email, phone, education, and registration date.

**offers** stores the candidate ID, company name, role, joining date, compensation text, status, and response timestamp. Each offer is connected to a candidate through `candidate_id`.

## Important limitations

This is an academic prototype, not a production HR platform. Before real use, add authentication and authorization, secure personal data, CSRF/rate-limit protections, audit logging, email notifications, backups, and a proper legal offer-document workflow. Do not upload real candidate data, credentials, or confidential offer letters to a public repository.

## Suggested future improvements

- Candidate and admin login
- Downloadable PDF offer letters
- Email reminders for pending offers
- Offer expiry dates and overdue notifications
- Search and filter candidates
- Deployment to a hosting service

## Author

Student Full Stack Development Project
