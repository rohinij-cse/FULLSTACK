const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const PORT = process.env.PORT || 3000;
const db = new sqlite3.Database(path.join(__dirname, "onboarding.db"));

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS candidates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL,
      education TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS offers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      candidate_id INTEGER NOT NULL,
      company_name TEXT NOT NULL,
      job_role TEXT NOT NULL,
      joining_date TEXT NOT NULL,
      annual_salary TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending',
      responded_at TEXT,
      FOREIGN KEY(candidate_id) REFERENCES candidates(id)
    )
  `);

  // Add a clearly labelled demo candidate and offer when the database is empty.
  db.get("SELECT COUNT(*) AS count FROM candidates", (err, row) => {
    if (err || !row || row.count > 0) return;
    db.run(
      `INSERT INTO candidates (full_name, email, phone, education) VALUES (?, ?, ?, ?)`,
      ["Demo Candidate", "demo@example.com", "9876543210", "B.E. Computer Science"],
      function (insertErr) {
        if (insertErr) return console.error(insertErr.message);
        db.run(
          `INSERT INTO offers (candidate_id, company_name, job_role, joining_date, annual_salary)
           VALUES (?, ?, ?, ?, ?)`,
          [this.lastID, "VertexMind (Demo)", "Java Programming Intern", "2026-11-15", "Internship stipend: ₹10,000/month"]
        );
      }
    );
  });
});

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}

// Register a candidate and create an initial demo offer for the candidate.
app.post("/api/candidates", (req, res) => {
  const fullName = clean(req.body.fullName);
  const email = clean(req.body.email).toLowerCase();
  const phone = clean(req.body.phone);
  const education = clean(req.body.education);

  if (!fullName || !email || !phone || !education) {
    return res.status(400).json({ error: "Please complete every field." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: "Please enter a valid email address." });
  }

  db.run(
    `INSERT INTO candidates (full_name, email, phone, education) VALUES (?, ?, ?, ?)`,
    [fullName, email, phone, education],
    function (err) {
      if (err && err.message.includes("UNIQUE")) {
        return res.status(409).json({ error: "This email is already registered." });
      }
      if (err) return res.status(500).json({ error: "Could not save candidate." });

      const candidateId = this.lastID;
      db.run(
        `INSERT INTO offers (candidate_id, company_name, job_role, joining_date, annual_salary)
         VALUES (?, ?, ?, ?, ?)`,
        [candidateId, "Example Company", "Graduate Trainee", "2026-12-01", "To be discussed"],
        (offerErr) => {
          if (offerErr) return res.status(500).json({ error: "Candidate saved, but offer creation failed." });
          res.status(201).json({ message: "Registration successful. Your offer is ready to review." });
        }
      );
    }
  );
});

// List candidates and their latest offer details for the dashboard.
app.get("/api/candidates", (req, res) => {
  const sql = `
    SELECT c.id, c.full_name, c.email, c.phone, c.education, c.created_at,
           o.id AS offer_id, o.company_name, o.job_role, o.joining_date,
           o.annual_salary, o.status, o.responded_at
    FROM candidates c
    LEFT JOIN offers o ON o.candidate_id = c.id
    ORDER BY c.id DESC
  `;
  db.all(sql, [], (err, rows) => {
    if (err) return res.status(500).json({ error: "Could not load candidates." });
    res.json(rows);
  });
});

// A candidate can accept or decline only an offer that is still pending.
app.patch("/api/offers/:id/respond", (req, res) => {
  const offerId = Number(req.params.id);
  const status = clean(req.body.status);
  if (!Number.isInteger(offerId) || offerId < 1) {
    return res.status(400).json({ error: "Invalid offer ID." });
  }
  if (!["Accepted", "Declined"].includes(status)) {
    return res.status(400).json({ error: "Choose Accepted or Declined." });
  }

  db.run(
    `UPDATE offers SET status = ?, responded_at = CURRENT_TIMESTAMP
     WHERE id = ? AND status = 'Pending'`,
    [status, offerId],
    function (err) {
      if (err) return res.status(500).json({ error: "Could not update offer." });
      if (this.changes === 0) {
        return res.status(409).json({ error: "Offer not found or a response has already been recorded." });
      }
      res.json({ message: `Offer ${status.toLowerCase()} successfully.` });
    }
  );
});

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

app.listen(PORT, () => {
  console.log(`Onboarding app running at http://localhost:${PORT}`);
});
