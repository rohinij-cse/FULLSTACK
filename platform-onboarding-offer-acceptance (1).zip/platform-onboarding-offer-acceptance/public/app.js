const form = document.getElementById("registrationForm");
const formMessage = document.getElementById("formMessage");
const offerList = document.getElementById("offerList");
const candidateTable = document.getElementById("candidateTable");

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
function statusClass(status) {
  return String(status || "Pending").toLowerCase();
}
function formatDate(date) {
  if (!date) return "Not specified";
  const parsed = new Date(`${date}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? date : parsed.toLocaleDateString(undefined, {year:"numeric",month:"short",day:"numeric"});
}
function showMessage(message, type) {
  formMessage.textContent = message;
  formMessage.className = `message ${type || ""}`;
}

async function loadDashboard() {
  try {
    const response = await fetch("/api/candidates");
    const candidates = await response.json();
    if (!response.ok) throw new Error(candidates.error || "Could not load data.");

    const pending = candidates.filter(c => c.status === "Pending").length;
    const accepted = candidates.filter(c => c.status === "Accepted").length;
    document.getElementById("totalCount").textContent = candidates.length;
    document.getElementById("pendingCount").textContent = pending;
    document.getElementById("acceptedCount").textContent = accepted;

    const withOffers = candidates.filter(c => c.offer_id);
    offerList.innerHTML = withOffers.length ? withOffers.map(c => `
      <div class="offer-card">
        <div class="offer-card-top">
          <div><h3>${escapeHtml(c.job_role)}</h3><p class="company">${escapeHtml(c.company_name)} · ${escapeHtml(c.full_name)}</p></div>
          <span class="status ${statusClass(c.status)}">${escapeHtml(c.status || "Pending")}</span>
        </div>
        <div class="offer-meta">
          <div><span class="meta-label">Joining date</span><span class="meta-value">${escapeHtml(formatDate(c.joining_date))}</span></div>
          <div><span class="meta-label">Compensation</span><span class="meta-value">${escapeHtml(c.annual_salary)}</span></div>
        </div>
        ${c.status === "Pending" ? `<div class="offer-actions">
          <button class="button accept-btn" data-offer="${c.offer_id}" data-status="Accepted">✓ Accept offer</button>
          <button class="button decline-btn" data-offer="${c.offer_id}" data-status="Declined">Decline</button>
        </div>` : `<p class="disabled-note">Response recorded${c.responded_at ? ` · ${escapeHtml(c.responded_at)}` : ""}.</p>`}
      </div>`).join("") : '<div class="empty">No offers yet. Register a candidate to create a demo offer.</div>';

    candidateTable.innerHTML = candidates.length ? candidates.map(c => `
      <tr>
        <td>${escapeHtml(c.full_name)}<small>${escapeHtml(c.email)}</small></td>
        <td>${escapeHtml(c.education)}</td>
        <td>${escapeHtml(c.job_role || "—")}</td>
        <td><span class="status ${statusClass(c.status)}">${escapeHtml(c.status || "No offer")}</span></td>
      </tr>`).join("") : '<tr><td colspan="4" class="empty">No candidates registered yet.</td></tr>';
  } catch (error) {
    offerList.innerHTML = `<p class="message error">${escapeHtml(error.message)} Start the Node.js server and refresh.</p>`;
    candidateTable.innerHTML = '<tr><td colspan="4" class="empty">Unable to load records.</td></tr>';
  }
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = "Creating profile…";
  try {
    const response = await fetch("/api/candidates", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Registration failed.");
    form.reset();
    showMessage(result.message, "success");
    await loadDashboard();
  } catch (error) {
    showMessage(error.message, "error");
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = 'Create my profile <span>→</span>';
  }
});

offerList.addEventListener("click", async event => {
  const button = event.target.closest("button[data-offer]");
  if (!button) return;
  const offerId = button.dataset.offer;
  const status = button.dataset.status;
  if (status === "Declined" && !confirm("Are you sure you want to decline this demo offer?")) return;
  button.disabled = true;
  try {
    const response = await fetch(`/api/offers/${offerId}/respond`, {
      method: "PATCH",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({status})
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Could not save response.");
    await loadDashboard();
  } catch (error) {
    alert(error.message);
    button.disabled = false;
  }
});

document.getElementById("refreshButton").addEventListener("click", loadDashboard);
loadDashboard();
