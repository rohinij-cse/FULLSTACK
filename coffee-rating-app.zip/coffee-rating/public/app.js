const grid = document.getElementById("grid");
const boardEl = document.getElementById("leaderboard");
const statusEl = document.getElementById("status");

let coffees = [];
let leaderboard = [];

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function beans(level) {
  return Array.from({ length: 5 }, (_, i) => `<span class="bean ${i < level ? "on" : ""}"></span>`).join("");
}

// Build the grid once; afterwards only the vote numbers are updated (no flicker, no reload)
function renderGrid() {
  if (grid.children.length !== coffees.length) {
    grid.innerHTML = coffees.map((c) => `
      <article class="card" data-id="${c.id}">
        <h3>${esc(c.name)}</h3>
        <p class="origin">${esc(c.origin)}</p>
        <div class="roast" aria-label="Roast level ${c.roast} of 5">${beans(c.roast)}</div>
        <p class="notes">${esc(c.notes)}</p>
        <div class="vote-row">
          <span class="count" data-count><span data-num>${c.votes}</span><small>votes</small></span>
          <button class="vote" data-vote="${c.id}" aria-label="Vote for ${esc(c.name)}">Vote</button>
        </div>
      </article>`).join("");
    return;
  }
  coffees.forEach((c) => {
    const num = grid.querySelector(`[data-id="${c.id}"] [data-num]`);
    if (num && num.textContent !== String(c.votes)) {
      num.textContent = c.votes;
      const wrap = num.parentElement;
      wrap.classList.remove("bump");
      void wrap.offsetWidth; // restart animation
      wrap.classList.add("bump");
    }
  });
}

function renderLeaderboard() {
  const max = Math.max(1, ...leaderboard.map((c) => c.votes));
  boardEl.innerHTML = leaderboard.some((c) => c.votes > 0)
    ? leaderboard.map((c, i) => `
        <li>
          <div class="row"><span><span class="rank">${i + 1}</span>${esc(c.name)}</span><strong>${c.votes}</strong></div>
          <div class="bar"><span style="width:${(c.votes / max) * 100}%"></span></div>
        </li>`).join("")
    : `<li class="empty">No votes yet. Cast the first one.</li>`;
}

function apply(data) {
  coffees = data.coffees;
  leaderboard = data.leaderboard;
  renderGrid();
  renderLeaderboard();
}

async function load() {
  const [c, l] = await Promise.all([fetch("/api/coffees"), fetch("/api/leaderboard")]);
  apply({ coffees: await c.json(), leaderboard: await l.json() });
}

// Vote: POST to the API, update this screen immediately from the response
grid.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-vote]");
  if (!btn) return;
  btn.disabled = true;
  try {
    const res = await fetch(`/api/coffees/${btn.dataset.vote}/vote`, { method: "POST" });
    if (!res.ok) throw new Error((await res.json()).error || "Vote failed");
    const updated = await res.json();
    coffees = coffees.map((c) => (c.id === updated.id ? updated : c));
    leaderboard = [...coffees].sort((a, b) => b.votes - a.votes || a.name.localeCompare(b.name)).slice(0, 5);
    renderGrid();
    renderLeaderboard();
  } catch (err) {
    statusEl.textContent = err.message;
  } finally {
    btn.disabled = false;
  }
});

// Live updates: the server pushes new scores whenever anyone votes
function connect() {
  const es = new EventSource("/api/stream");
  es.onopen = () => (statusEl.textContent = "Live: scores update as people vote");
  es.onmessage = (e) => apply(JSON.parse(e.data));
  es.onerror = () => (statusEl.textContent = "Reconnecting…");
}

load().then(connect).catch(() => (statusEl.textContent = "Could not load coffees. Is the server running?"));
