// Minimal smoke test: node test.js
process.env.DB_FILE = ":memory:";
const assert = require("assert");
const app = require("./app");

const server = app.listen(0, async () => {
  const base = `http://localhost:${server.address().port}`;
  try {
    const list = await (await fetch(`${base}/api/coffees`)).json();
    assert(list.length > 0, "seed data present");
    const first = list[0];

    const voted = await (await fetch(`${base}/api/coffees/${first.id}/vote`, { method: "POST" })).json();
    assert.strictEqual(voted.votes, first.votes + 1, "vote increments by 1");

    const top = await (await fetch(`${base}/api/leaderboard`)).json();
    assert.strictEqual(top[0].id, first.id, "voted coffee leads leaderboard");

    const bad = await fetch(`${base}/api/coffees/9999/vote`, { method: "POST" });
    assert.strictEqual(bad.status, 404, "unknown id returns 404");

    console.log("All tests passed");
    process.exit(0);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
});
