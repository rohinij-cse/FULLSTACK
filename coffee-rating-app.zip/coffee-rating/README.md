# Coffee Rating App

An interactive voting app: browse coffee blends, vote for your favourite, and watch the leaderboard change live. Votes are stored in a SQLite database through a Node/Express API.

## Features
- Grid of coffee blends (origin, roast level, tasting notes)
- `POST /api/coffees/:id/vote` atomically increments the vote counter in the database
- UI updates instantly without a page refresh
- Live updates across browser tabs and users via Server-Sent Events
- Top-5 leaderboard with progress bars

## Tech stack
Node.js, Express, SQLite (`better-sqlite3`), vanilla HTML/CSS/JS

## Run locally
```bash
npm install
npm start
# open http://localhost:3000
```
Run the API smoke test with `npm test`.

## API
| Method | Endpoint | Description |
| --- | --- | --- |
| GET | `/api/coffees` | List all coffees with vote counts |
| POST | `/api/coffees/:id/vote` | Add one vote, returns the updated coffee |
| GET | `/api/leaderboard?limit=5` | Top-rated coffees |
| GET | `/api/stream` | SSE stream of live scores |

## Project structure
```
server.js        starts the server
app.js           Express routes + SSE broadcast
db.js            SQLite schema, seed data, queries
public/          frontend (index.html, style.css, app.js)
test.js          API smoke test
```

## Possible improvements
Limit one vote per user per coffee, add user accounts, let users add new blends.
