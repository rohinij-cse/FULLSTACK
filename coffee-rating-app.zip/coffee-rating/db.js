const Database = require("better-sqlite3");
const path = require("path");

const DB_FILE = process.env.DB_FILE || path.join(__dirname, "coffee.db");
const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS coffees (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL UNIQUE,
    origin  TEXT NOT NULL,
    roast   INTEGER NOT NULL CHECK (roast BETWEEN 1 AND 5),
    notes   TEXT NOT NULL,
    votes   INTEGER NOT NULL DEFAULT 0
  );
`);

// Seed sample blends the first time the database is created
const count = db.prepare("SELECT COUNT(*) AS n FROM coffees").get().n;
if (count === 0) {
  const seed = [
    ["Ethiopia Yirgacheffe", "Ethiopia", 2, "Jasmine, bergamot, lemon zest"],
    ["Colombia Huila", "Colombia", 3, "Red apple, caramel, milk chocolate"],
    ["Sumatra Mandheling", "Indonesia", 4, "Cedar, dark cocoa, earthy"],
    ["Kenya AA", "Kenya", 2, "Blackcurrant, grapefruit, bright"],
    ["Brazil Santos", "Brazil", 3, "Hazelnut, peanut, low acidity"],
    ["Italian Espresso Blend", "Blend", 5, "Smoky, bittersweet, thick crema"],
    ["Guatemala Antigua", "Guatemala", 3, "Brown sugar, orange, spice"],
    ["Monsooned Malabar", "India", 4, "Spicy, woody, full body"],
  ];
  const insert = db.prepare(
    "INSERT INTO coffees (name, origin, roast, notes) VALUES (?, ?, ?, ?)"
  );
  db.transaction((rows) => rows.forEach((r) => insert.run(...r)))(seed);
}

module.exports = {
  all: () => db.prepare("SELECT * FROM coffees ORDER BY id").all(),
  top: (limit = 5) =>
    db
      .prepare("SELECT * FROM coffees ORDER BY votes DESC, name ASC LIMIT ?")
      .all(limit),
  get: (id) => db.prepare("SELECT * FROM coffees WHERE id = ?").get(id),
  // Atomic increment: safe even with many simultaneous voters
  vote: (id) => {
    const res = db
      .prepare("UPDATE coffees SET votes = votes + 1 WHERE id = ?")
      .run(id);
    return res.changes ? db.prepare("SELECT * FROM coffees WHERE id = ?").get(id) : null;
  },
  close: () => db.close(),
};
