const express = require("express");
const path = require("path");
const db = require("./db");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// --- Server-Sent Events: pushes fresh scores to every open browser tab ---
const clients = new Set();
function broadcast() {
  const payload = `data: ${JSON.stringify({ coffees: db.all(), leaderboard: db.top(5) })}\n\n`;
  for (const res of clients) res.write(payload);
}

app.get("/api/stream", (req, res) => {
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
  });
  res.flushHeaders();
  clients.add(res);
  req.on("close", () => clients.delete(res));
});

// --- REST API ---
app.get("/api/coffees", (req, res) => res.json(db.all()));

app.get("/api/leaderboard", (req, res) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 5, 20);
  res.json(db.top(limit));
});

app.post("/api/coffees/:id/vote", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid coffee id" });
  const updated = db.vote(id);
  if (!updated) return res.status(404).json({ error: "Coffee not found" });
  broadcast();
  res.json(updated);
});

module.exports = app;
