import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { existsSync } from "node:fs";
import { items } from "./data.js";

const app = express();
const PORT = process.env.PORT || 4000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors());
app.use(express.json());

const categories = [...new Set(items.map((item) => item.category))];

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "live-query-filter-system" });
});

app.get("/api/categories", (_req, res) => {
  res.json({ data: categories });
});

app.get("/api/items", (req, res) => {
  const search = String(req.query.search ?? "").trim().toLowerCase();
  const rawCategory = req.query.category ?? "";
  const selectedCategories = (Array.isArray(rawCategory) ? rawCategory : String(rawCategory).split(","))
    .map((value) => String(value).trim())
    .filter(Boolean);

  const requestedPage = Number.parseInt(req.query.page, 10);
  const requestedLimit = Number.parseInt(req.query.limit, 10);
  const page = Number.isFinite(requestedPage) && requestedPage > 0 ? requestedPage : 1;
  const limit = Number.isFinite(requestedLimit) && requestedLimit > 0
    ? Math.min(requestedLimit, 24)
    : 6;

  const filtered = items.filter((item) => {
    const matchesSearch = !search || [
      item.title,
      item.description,
      item.category,
      ...item.tags
    ].some((value) => value.toLowerCase().includes(search));

    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(item.category);
    return matchesSearch && matchesCategory;
  });

  const total = filtered.length;
  const totalPages = Math.ceil(total / limit);
  const safePage = totalPages > 0 ? Math.min(page, totalPages) : 1;
  const start = (safePage - 1) * limit;

  res.json({
    data: filtered.slice(start, start + limit),
    pagination: { page: safePage, limit, total, totalPages },
    filters: { search, categories: selectedCategories }
  });
});

const distPath = path.resolve(__dirname, "../dist");
if (existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));
}

app.listen(PORT, () => {
  console.log(`API server running at http://localhost:${PORT}`);
});