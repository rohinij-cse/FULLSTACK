import { useEffect, useMemo, useState } from "react";
import { Search, SlidersHorizontal, ArrowUpRight, ChevronLeft, ChevronRight, X, Layers3, Sparkles } from "lucide-react";

const API_BASE = import.meta.env.VITE_API_BASE || "";
const CATEGORIES = ["Design", "Development", "Analytics"];
const PAGE_SIZE = 6;

function useDebouncedValue(value, delay = 350) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delay);
    return () => window.clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

function SkeletonCard() {
  return <div className="card skeleton-card" aria-hidden="true">
    <div className="skeleton skeleton-icon" />
    <div className="skeleton skeleton-line wide" />
    <div className="skeleton skeleton-line" />
    <div className="skeleton skeleton-line short" />
    <div className="skeleton skeleton-footer" />
  </div>;
}

function ResultCard({ item, index }) {
  return <article className="card result-card" style={{ animationDelay: `${index * 45}ms` }}>
    <div className="card-top">
      <div className={`item-icon ${item.color || "violet"}`}>{item.icon || <Layers3 size={22} />}</div>
      <span className="category-pill">{item.category}</span>
      <button className="open-button" aria-label={`Open ${item.title}`} title="Demo card">
        <ArrowUpRight size={17} />
      </button>
    </div>
    <h3>{item.title}</h3>
    <p className="card-description">{item.description}</p>
    <div className="tags">{item.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
    <div className="card-bottom"><span className="status-dot" /> Ready to explore <span className="card-id">ID {String(item.id).padStart(3, "0")}</span></div>
  </article>;
}

export default function App() {
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search, 350);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [page, setPage] = useState(1);
  const [payload, setPayload] = useState({ data: [], pagination: { page: 1, limit: PAGE_SIZE, total: 0, totalPages: 0 } });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const categoryQuery = useMemo(() => selectedCategories.join(","), [selectedCategories]);

  useEffect(() => { setPage(1); }, [debouncedSearch, categoryQuery]);

  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({ search: debouncedSearch, category: categoryQuery, page: String(page), limit: String(PAGE_SIZE) });
    setLoading(true);
    setError("");

    fetch(`${API_BASE}/api/items?${params.toString()}`, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("The server returned an unexpected response.");
        return response.json();
      })
      .then((result) => setPayload(result))
      .catch((err) => {
        if (err.name !== "AbortError") setError("Could not load results. Make sure the API server is running, then try again.");
      })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });

    return () => controller.abort();
  }, [debouncedSearch, categoryQuery, page]);

  const pagination = payload.pagination;
  const toggleCategory = (category) => {
    setSelectedCategories((current) => current.includes(category)
      ? current.filter((item) => item !== category)
      : [...current, category]);
  };
  const clearFilters = () => { setSearch(""); setSelectedCategories([]); setPage(1); };
  const firstResult = pagination.total ? (pagination.page - 1) * pagination.limit + 1 : 0;
  const lastResult = Math.min(pagination.page * pagination.limit, pagination.total);

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" aria-label="QueryBoard home"><span className="brand-mark"><Layers3 size={19} /></span><span>query<span className="brand-accent">board</span></span></a>
      <div className="topbar-right"><span className="api-status"><span /> API connected</span><span className="avatar">QB</span></div>
    </header>

    <main className="main-content">
      <section className="hero">
        <div className="eyebrow"><Sparkles size={14} /> LIVE QUERY EXPLORER</div>
        <h1>Find your next <span>big idea.</span></h1>
        <p className="hero-copy">Search, filter, and discover projects from one focused workspace.</p>
        <div className="search-wrap">
          <Search size={20} className="search-icon" />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search projects, tags, or keywords..." aria-label="Search projects" />
          {search && <button className="clear-search" onClick={() => setSearch("")} aria-label="Clear search"><X size={17} /></button>}
          <kbd>⌘ K</kbd>
        </div>
        <div className="search-hint"><span className="live-dot" /> Search updates automatically <span className="hint-divider">·</span> 350ms debounce</div>
      </section>

      <section className="workspace">
        <aside className="filters-panel">
          <div className="filter-heading"><div><SlidersHorizontal size={17} /><h2>Filters</h2></div>{(search || selectedCategories.length > 0) && <button onClick={clearFilters}>Reset</button>}</div>
          <div className="filter-section">
            <div className="section-label">CATEGORY <span>{selectedCategories.length || "All"}</span></div>
            <div className="checkbox-list">
              {CATEGORIES.map((category) => <label className="check-row" key={category}>
                <input type="checkbox" checked={selectedCategories.includes(category)} onChange={() => toggleCategory(category)} />
                <span className="custom-check" />
                <span>{category}</span>
                <span className="filter-count">{category === "Design" ? 6 : category === "Development" ? 6 : 6}</span>
              </label>)}
            </div>
          </div>
          <div className="filter-note"><div className="note-icon"><Sparkles size={16} /></div><div><strong>Pro tip</strong><p>Combine categories with search to narrow down your results.</p></div></div>
          <div className="api-note"><span className="api-note-dot" /> <span>Powered by live API queries</span></div>
        </aside>

        <section className="results-section">
          <div className="results-header">
            <div><div className="results-title-row"><h2>Explore projects</h2><span className="result-count">{pagination.total}</span></div><p className="results-subtitle">{loading ? "Finding matching projects…" : `Showing ${firstResult}–${lastResult} of ${pagination.total} results`}</p></div>
            <div className="sort-label"><span className="sort-dot" /> Relevance <span className="chevron">⌄</span></div>
          </div>

          {error ? <div className="state-panel error-panel"><div className="state-symbol">!</div><h3>Something went wrong</h3><p>{error}</p><button className="primary-button" onClick={() => setPage((current) => current)}>Try again</button></div>
          : loading ? <div className="cards-grid">{Array.from({ length: PAGE_SIZE }, (_, index) => <SkeletonCard key={index} />)}</div>
          : payload.data.length === 0 ? <div className="state-panel"><div className="state-symbol"><Search size={22} /></div><h3>No projects found</h3><p>Try another keyword or remove one of your filters.</p><button className="primary-button" onClick={clearFilters}>Clear all filters</button></div>
          : <div className="cards-grid">{payload.data.map((item, index) => <ResultCard key={item.id} item={item} index={index} />)}</div>}

          <div className="pagination-row">
            <span className="page-summary">Page <strong>{pagination.page}</strong> of <strong>{Math.max(1, pagination.totalPages)}</strong></span>
            <div className="pagination-controls">
              <button className="page-button" disabled={loading || page <= 1} onClick={() => setPage((current) => Math.max(1, current - 1))}><ChevronLeft size={17} /><span>Previous</span></button>
              {Array.from({ length: Math.max(1, pagination.totalPages) }, (_, index) => index + 1).slice(0, 5).map((number) => <button key={number} className={`number-button ${pagination.page === number ? "active" : ""}`} disabled={loading} onClick={() => setPage(number)}>{number}</button>)}
              <button className="page-button" disabled={loading || page >= pagination.totalPages} onClick={() => setPage((current) => current + 1)}><span>Next</span><ChevronRight size={17} /></button>
            </div>
          </div>
        </section>
      </section>
      <footer><span>© 2025 QueryBoard</span><span>Built for finding what matters <span className="footer-heart">✦</span></span><span className="footer-tech">React <b>·</b> Express <b>·</b> REST API</span></footer>
    </main>
  </div>;
}