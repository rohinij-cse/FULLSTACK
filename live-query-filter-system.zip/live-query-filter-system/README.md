# Live Query Filter System

A full-stack demo featuring debounced search, multi-category filtering, API-driven pagination, loading states, and responsive result cards.

## Features

- Express API accepts `search`, `category`, `page`, and `limit` query parameters.
- Frontend debounces search input by 350 ms to reduce unnecessary network requests.
- Filter multiple categories simultaneously using checkboxes.
- Paginated result grid with total result count and page controls.
- Loading skeletons, empty state, error feedback, and clear-filters action.
- Responsive UI built with React and Vite.
- Demo data is stored in `server/data.js`; no database setup is needed.

## Requirements

- Node.js 18 or newer
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the Vite URL printed in the terminal (usually http://localhost:5173). The API runs on http://localhost:4000.

## API

`GET /api/items?search=design&category=Design,Development&page=1&limit=6`

- `search`: optional case-insensitive search across title, description, and tags
- `category`: optional comma-separated list of categories
- `page`: page number (defaults to `1`)
- `limit`: results per page (defaults to `6`, max `24`)

Example response:

```json
{
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 6,
    "total": 0,
    "totalPages": 0
  },
  "filters": {
    "search": "design",
    "categories": ["Design"]
  }
}
```

Health check: `GET /api/health`

## Build for production

```bash
npm run build
npm start
```

The API server serves the built frontend from `dist` when the build exists.

## Push to GitHub

1. Extract this ZIP.
2. Open a terminal inside the extracted project folder.
3. Run `npm install` and `npm run dev` to test it.
4. Create a new empty repository on GitHub.
5. Run the following commands from the project folder:

```bash
git init
git add .
git commit -m "Build live query filter system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own repository URL. Do not commit `node_modules` or secrets.
