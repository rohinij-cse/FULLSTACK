const express = require("express");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const path = require("path");
const db = require("./db");
const { signToken, setAuthCookie, clearAuthCookie, requireAuth } = require("./auth");

const app = express();
app.use(express.json({ limit: "10kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

const SALT_ROUNDS = 12;
// Compared against when the email is unknown, so response time doesn't reveal which emails exist
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", SALT_ROUNDS);

// Slows down password guessing: max 20 attempts per 15 minutes per IP
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many attempts. Try again in a few minutes." },
});

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email });

// Step 1 + 2: register. The password is hashed with bcrypt before it is saved.
app.post("/api/auth/register", authLimiter, async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (!name || name.length > 80) return res.status(400).json({ error: "Name is required (max 80 characters)" });
  if (!EMAIL_RE.test(email)) return res.status(400).json({ error: "Enter a valid email address" });
  // bcrypt only uses the first 72 bytes, so longer passwords are rejected rather than silently truncated
  if (password.length < 8 || Buffer.byteLength(password) > 72)
    return res.status(400).json({ error: "Password must be 8 to 72 characters" });
  if (db.findUserByEmail(email)) return res.status(409).json({ error: "An account with this email already exists" });

  const hash = await bcrypt.hash(password, SALT_ROUNDS);
  const id = db.createUser(name, email, hash);
  const user = db.findUserById(id);
  setAuthCookie(res, signToken(user)); // log the user in right after registering
  res.status(201).json({ user: publicUser(user) });
});

// Step 1 + 3: login. Same error message for "no such user" and "wrong password".
app.post("/api/auth/login", authLimiter, async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.findUserByEmail(email);
  const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) return res.status(401).json({ error: "Invalid email or password" });

  const token = signToken(user);
  setAuthCookie(res, token);
  // The token is also returned so API clients (Postman, mobile apps) can use the Authorization header.
  res.json({ user: publicUser(user), token });
});

app.post("/api/auth/logout", (req, res) => {
  clearAuthCookie(res);
  res.status(204).end();
});

// Step 4: protected routes. requireAuth verifies the JWT before the handler runs.
app.get("/api/auth/me", requireAuth, (req, res) => {
  const user = db.findUserById(req.user.id);
  if (!user) return res.status(401).json({ error: "Account no longer exists" });
  res.json({ user: publicUser(user) });
});

app.get("/api/notes", requireAuth, (req, res) => res.json(db.notes(req.user.id)));

app.post("/api/notes", requireAuth, (req, res) => {
  const text = String(req.body.text || "").trim();
  if (!text || text.length > 500) return res.status(400).json({ error: "Note text is required (max 500 characters)" });
  res.status(201).json(db.addNote(req.user.id, text));
});

app.delete("/api/notes/:id", requireAuth, (req, res) => {
  if (!db.deleteNote(req.user.id, Number(req.params.id))) return res.status(404).json({ error: "Note not found" });
  res.status(204).end();
});

module.exports = app;
