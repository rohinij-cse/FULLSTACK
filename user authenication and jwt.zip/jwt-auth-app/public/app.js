const $ = (id) => document.getElementById(id);
let mode = "login";

// The JWT lives in an HTTP-only cookie, so this script never touches the token itself.
async function api(path, options = {}) {
  const res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...options });
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) throw Object.assign(new Error((data && data.error) || "Something went wrong"), { status: res.status });
  return data;
}

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function setMode(m) {
  mode = m;
  const reg = m === "register";
  $("tab-login").setAttribute("aria-selected", String(!reg));
  $("tab-register").setAttribute("aria-selected", String(reg));
  $("name-field").hidden = !reg;
  $("name").required = reg;
  $("password").autocomplete = reg ? "new-password" : "current-password";
  $("submit").textContent = reg ? "Create account" : "Log in";
  $("error").textContent = "";
}

function showAuth() { $("app-view").hidden = true; $("auth-view").hidden = false; }
async function showApp(user) {
  $("auth-view").hidden = true;
  $("app-view").hidden = false;
  $("user-name").textContent = user.name;
  await loadNotes();
}

async function loadNotes() {
  try {
    const notes = await api("/api/notes");
    $("notes").innerHTML = notes.length
      ? notes.map((n) => `<li><span>${esc(n.text)}</span><button class="del" data-id="${n.id}" aria-label="Delete note">×</button></li>`).join("")
      : `<li class="empty">No notes yet. Add your first one above.</li>`;
  } catch (e) {
    if (e.status === 401) showAuth(); // token expired or invalid
  }
}

$("tab-login").onclick = () => setMode("login");
$("tab-register").onclick = () => setMode("register");

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("error").textContent = "";
  $("submit").disabled = true;
  try {
    const body = { email: $("email").value, password: $("password").value };
    if (mode === "register") body.name = $("name").value;
    const { user } = await api(`/api/auth/${mode}`, { method: "POST", body: JSON.stringify(body) });
    $("form").reset();
    await showApp(user);
  } catch (err) {
    $("error").textContent = err.message;
  } finally {
    $("submit").disabled = false;
  }
});

$("logout").onclick = async () => { await api("/api/auth/logout", { method: "POST" }); showAuth(); };

$("note-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  await api("/api/notes", { method: "POST", body: JSON.stringify({ text: $("note-text").value }) });
  $("note-text").value = "";
  loadNotes();
});

$("notes").addEventListener("click", async (e) => {
  if (!e.target.dataset.id) return;
  await api(`/api/notes/${e.target.dataset.id}`, { method: "DELETE" });
  loadNotes();
});

// On page load: if the cookie holds a valid token, go straight to the app
api("/api/auth/me").then(({ user }) => showApp(user)).catch(showAuth);
