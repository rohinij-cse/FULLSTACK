const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(process.env.DB_FILE || path.join(__dirname, "auth.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,           -- bcrypt hash, never the plain password
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    text       TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

module.exports = {
  findUserByEmail: (email) => db.prepare("SELECT * FROM users WHERE email = ?").get(email),
  findUserById: (id) => db.prepare("SELECT id, name, email, created_at FROM users WHERE id = ?").get(id),
  createUser: (name, email, hash) =>
    db.prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)").run(name, email, hash).lastInsertRowid,
  notes: (userId) => db.prepare("SELECT id, text, created_at FROM notes WHERE user_id = ? ORDER BY id DESC").all(userId),
  addNote: (userId, text) => {
    const id = db.prepare("INSERT INTO notes (user_id, text) VALUES (?, ?)").run(userId, text).lastInsertRowid;
    return db.prepare("SELECT id, text, created_at FROM notes WHERE id = ?").get(id);
  },
  deleteNote: (userId, id) => db.prepare("DELETE FROM notes WHERE id = ? AND user_id = ?").run(id, userId).changes > 0,
};
