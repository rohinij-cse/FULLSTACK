const jwt = require("jsonwebtoken");

const isProd = process.env.NODE_ENV === "production";

if (!process.env.JWT_SECRET) {
  if (isProd) throw new Error("JWT_SECRET must be set in production");
  console.warn("WARNING: JWT_SECRET not set. Using an insecure development secret.");
}
const SECRET = process.env.JWT_SECRET || "dev-only-insecure-secret";
const EXPIRES_IN = "1h";
const COOKIE_NAME = "token";

// Step 3: issue a signed token. Claims: sub (user id), email, iat and exp (added automatically).
function signToken(user) {
  return jwt.sign({ sub: String(user.id), email: user.email }, SECRET, { algorithm: "HS256", expiresIn: EXPIRES_IN });
}

// HTTP-only cookie: JavaScript in the page cannot read it, which protects it from XSS theft.
function setAuthCookie(res, token) {
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: isProd,          // HTTPS only in production
    sameSite: "strict",      // not sent on cross-site requests (CSRF protection)
    maxAge: 60 * 60 * 1000,
  });
}
const clearAuthCookie = (res) => res.clearCookie(COOKIE_NAME, { httpOnly: true, secure: isProd, sameSite: "strict" });

// Step 4: middleware that protects routes. Accepts the cookie or an "Authorization: Bearer <token>" header.
function requireAuth(req, res, next) {
  const header = req.get("Authorization") || "";
  const token = req.cookies[COOKIE_NAME] || (header.startsWith("Bearer ") ? header.slice(7) : null);
  if (!token) return res.status(401).json({ error: "Authentication required" });
  try {
    const claims = jwt.verify(token, SECRET, { algorithms: ["HS256"] }); // checks signature and expiry
    req.user = { id: Number(claims.sub), email: claims.email };
    next();
  } catch (err) {
    const msg = err.name === "TokenExpiredError" ? "Session expired, please log in again" : "Invalid token";
    res.status(401).json({ error: msg });
  }
}

module.exports = { signToken, setAuthCookie, clearAuthCookie, requireAuth, SECRET };
