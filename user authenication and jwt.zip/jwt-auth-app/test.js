// Auth tests: node test.js
process.env.DB_FILE = ":memory:";
process.env.JWT_SECRET = "test-secret";
const assert = require("assert");
const jwt = require("jsonwebtoken");
const app = require("./app");
const db = require("./db");

const server = app.listen(0, async () => {
  const base = `http://localhost:${server.address().port}`;
  const J = { "Content-Type": "application/json" };
  const post = (p, body, headers = {}) => fetch(base + p, { method: "POST", headers: { ...J, ...headers }, body: JSON.stringify(body) });
  const user = { name: "Test", email: "Test@Example.com", password: "supersecret1" };
  try {
    // register: validation
    assert.strictEqual((await post("/api/auth/register", { ...user, password: "short" })).status, 400, "weak password rejected");
    assert.strictEqual((await post("/api/auth/register", { ...user, email: "nope" })).status, 400, "bad email rejected");

    // register: success, password stored as a bcrypt hash
    const reg = await post("/api/auth/register", user);
    assert.strictEqual(reg.status, 201);
    const stored = db.findUserByEmail("test@example.com");
    assert(stored.password_hash.startsWith("$2"), "password is bcrypt hashed");
    assert.notStrictEqual(stored.password_hash, user.password, "plain password never stored");
    assert.strictEqual((await post("/api/auth/register", user)).status, 409, "duplicate email rejected");

    // login
    assert.strictEqual((await post("/api/auth/login", { email: user.email, password: "wrongpass1" })).status, 401);
    assert.strictEqual((await post("/api/auth/login", { email: "ghost@example.com", password: "whatever12" })).status, 401);
    const login = await post("/api/auth/login", { email: user.email, password: user.password });
    assert.strictEqual(login.status, 200);
    const setCookie = login.headers.get("set-cookie");
    assert(/HttpOnly/i.test(setCookie) && /SameSite=Strict/i.test(setCookie), "cookie is HttpOnly + SameSite=Strict");
    const { token } = await login.json();
    const cookie = setCookie.split(";")[0];

    // protected routes
    assert.strictEqual((await fetch(`${base}/api/auth/me`)).status, 401, "no token -> 401");
    assert.strictEqual((await fetch(`${base}/api/auth/me`, { headers: { Cookie: cookie } })).status, 200, "cookie works");
    assert.strictEqual((await fetch(`${base}/api/auth/me`, { headers: { Authorization: `Bearer ${token}` } })).status, 200, "bearer works");
    assert.strictEqual((await fetch(`${base}/api/auth/me`, { headers: { Authorization: `Bearer ${token}x` } })).status, 401, "tampered token -> 401");
    const expired = jwt.sign({ sub: "1", email: "a@b.c" }, "test-secret", { expiresIn: -10 });
    assert.strictEqual((await fetch(`${base}/api/auth/me`, { headers: { Authorization: `Bearer ${expired}` } })).status, 401, "expired token -> 401");
    const forged = jwt.sign({ sub: "1", email: "a@b.c" }, "wrong-secret");
    assert.strictEqual((await fetch(`${base}/api/auth/me`, { headers: { Authorization: `Bearer ${forged}` } })).status, 401, "wrong secret -> 401");

    // notes belong to the logged-in user only
    const H = { Cookie: cookie };
    const note = await (await post("/api/notes", { text: "hello" }, H)).json();
    assert.strictEqual((await (await fetch(`${base}/api/notes`, { headers: H })).json()).length, 1);
    await post("/api/auth/register", { name: "Other", email: "other@example.com", password: "anotherpass1" });
    const otherLogin = await post("/api/auth/login", { email: "other@example.com", password: "anotherpass1" });
    const otherCookie = otherLogin.headers.get("set-cookie").split(";")[0];
    assert.strictEqual((await fetch(`${base}/api/notes/${note.id}`, { method: "DELETE", headers: { Cookie: otherCookie } })).status, 404, "cannot delete another user's note");

    console.log("All tests passed");
    process.exit(0);
  } catch (e) { console.error(e); process.exit(1); }
});
