# JWT Authentication App

Registration and login with bcrypt-hashed passwords, signed JSON Web Tokens, and protected API routes. A small notes app shows that each user can only see and change their own data.

## Features
- `POST /api/auth/register` and `POST /api/auth/login`
- Passwords hashed with bcrypt (12 salt rounds) before they reach the database
- JWT signed with HS256 (1 hour expiry), sent in an **HTTP-only, SameSite=Strict cookie**
- `requireAuth` middleware verifies signature and expiry, and also accepts `Authorization: Bearer <token>` for API clients
- Rate limiting on auth routes, input validation, and identical error messages for unknown email and wrong password

## Tech stack
Node.js, Express, SQLite (`better-sqlite3`), `bcryptjs`, `jsonwebtoken`, `cookie-parser`, `express-rate-limit`

> `bcryptjs` is a pure-JavaScript implementation of the bcrypt algorithm. It produces standard `$2` bcrypt hashes and avoids native build problems. To use the native `bcrypt` package instead, run `npm i bcrypt` and change the `require` line in `app.js`; the API is the same.

## Run locally
```bash
npm install
cp .env.example .env     # then set JWT_SECRET (see the file for a command to generate one)
export JWT_SECRET=...    # or load .env with your own tooling; Node 20.6+ also supports: node --env-file=.env server.js
npm start                # http://localhost:3000
```
Without `JWT_SECRET` the app runs in development with an insecure default and prints a warning. In production (`NODE_ENV=production`) it refuses to start without one.

`npm test` runs the auth tests (hashing, duplicate emails, wrong password, tampered/expired/forged tokens, per-user data).

## API
| Method | Endpoint | Auth | Description |
| --- | --- | --- | --- |
| POST | `/api/auth/register` | no | `{ name, email, password }`, creates account and logs in |
| POST | `/api/auth/login` | no | `{ email, password }`, sets cookie, also returns `token` |
| POST | `/api/auth/logout` | no | Clears the cookie |
| GET | `/api/auth/me` | yes | Current user |
| GET / POST | `/api/notes` | yes | List / create the user's notes |
| DELETE | `/api/notes/:id` | yes | Delete one of the user's notes |

## Cookie vs localStorage
This project stores the token in an HTTP-only cookie. JavaScript cannot read it, so an XSS bug cannot steal it, and `SameSite=Strict` blocks cross-site request forgery. Storing the JWT in `localStorage` is simpler for separate frontends but exposes it to any injected script. The Bearer header support is there for tools like Postman or a mobile app.

## Database
```sql
users (id, name, email UNIQUE, password_hash, created_at)
notes (id, user_id -> users.id, text, created_at)
```

## Project structure
```
server.js   starts the server
app.js      routes
auth.js     JWT signing, cookie helpers, requireAuth middleware
db.js       SQLite schema and queries
public/     frontend
test.js     tests
```
