const express = require("express");
const path = require("path");
const db = require("./db");
const quotes = require("./quotes");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Each browser gets an anonymous id (stored in localStorage) so favourites are per user
function requireUser(req, res, next) {
  const id = req.get("X-User-Id");
  if (!id || !/^[\w-]{8,64}$/.test(id)) return res.status(400).json({ error: "Missing or invalid X-User-Id header" });
  req.userId = id;
  next();
}

app.get("/api/quote/today", async (req, res) => res.json(await quotes.getToday()));
app.get("/api/quote/random", async (req, res) => res.json(await quotes.getRandom()));

app.get("/api/favorites", requireUser, (req, res) => res.json(db.list(req.userId)));

app.post("/api/favorites", requireUser, (req, res) => {
  const text = String(req.body.text || "").trim();
  const author = String(req.body.author || "Unknown").trim();
  if (!text || text.length > 1000) return res.status(400).json({ error: "Quote text is required (max 1000 characters)" });
  res.status(201).json(db.add(req.userId, text, author.slice(0, 200)));
});

app.delete("/api/favorites/:id", requireUser, (req, res) => {
  const ok = db.remove(req.userId, Number(req.params.id));
  if (!ok) return res.status(404).json({ error: "Favourite not found" });
  res.status(204).end();
});

module.exports = app;
