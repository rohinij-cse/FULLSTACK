const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(process.env.DB_FILE || path.join(__dirname, "quotes.db"));
db.pragma("journal_mode = WAL");

// Step 2: table that stores each user's favourite quotes
db.exec(`
  CREATE TABLE IF NOT EXISTS favorites (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    TEXT NOT NULL,
    text       TEXT NOT NULL,
    author     TEXT NOT NULL DEFAULT 'Unknown',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, text)
  );
  CREATE INDEX IF NOT EXISTS idx_favorites_user ON favorites (user_id, created_at DESC);
`);

module.exports = {
  list: (userId) =>
    db.prepare("SELECT * FROM favorites WHERE user_id = ? ORDER BY created_at DESC, id DESC").all(userId),
  add: (userId, text, author) => {
    // INSERT OR IGNORE: favouriting the same quote twice does not create duplicates
    db.prepare("INSERT OR IGNORE INTO favorites (user_id, text, author) VALUES (?, ?, ?)").run(userId, text, author);
    return db.prepare("SELECT * FROM favorites WHERE user_id = ? AND text = ?").get(userId, text);
  },
  remove: (userId, id) =>
    db.prepare("DELETE FROM favorites WHERE id = ? AND user_id = ?").run(id, userId).changes > 0,
};
