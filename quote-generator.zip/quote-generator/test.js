// Smoke test with the external API mocked: node test.js
process.env.DB_FILE = ":memory:";
const assert = require("assert");

global.fetch = ((realFetch) => async (url, opts) => {
  if (String(url).includes("zenquotes.io/api/random")) return { ok: true, json: async () => [{ q: "Mock quote", a: "Tester" }] };
  if (String(url).includes("zenquotes.io/api/today")) return { ok: true, json: async () => [{ q: "Quote of the day", a: "Tester" }] };
  return realFetch(url, opts);
})(global.fetch);

const app = require("./app");
const server = app.listen(0, async () => {
  const base = `http://localhost:${server.address().port}`;
  const H = { "Content-Type": "application/json", "X-User-Id": "user-12345678" };
  try {
    const rnd = await (await fetch(`${base}/api/quote/random`)).json();
    assert.deepStrictEqual([rnd.text, rnd.author], ["Mock quote", "Tester"]);
    const today = await (await fetch(`${base}/api/quote/today`)).json();
    assert.strictEqual(today.text, "Quote of the day");

    const add = await fetch(`${base}/api/favorites`, { method: "POST", headers: H, body: JSON.stringify(rnd) });
    assert.strictEqual(add.status, 201);
    await fetch(`${base}/api/favorites`, { method: "POST", headers: H, body: JSON.stringify(rnd) }); // duplicate
    const list = await (await fetch(`${base}/api/favorites`, { headers: H })).json();
    assert.strictEqual(list.length, 1, "duplicates are ignored");

    const other = await (await fetch(`${base}/api/favorites`, { headers: { "X-User-Id": "someone-else-1" } })).json();
    assert.strictEqual(other.length, 0, "favourites are per user");

    const del = await fetch(`${base}/api/favorites/${list[0].id}`, { method: "DELETE", headers: H });
    assert.strictEqual(del.status, 204);
    const noUser = await fetch(`${base}/api/favorites`);
    assert.strictEqual(noUser.status, 400);

    console.log("All tests passed");
    process.exit(0);
  } catch (e) { console.error(e); process.exit(1); }
});
