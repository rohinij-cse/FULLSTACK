# Quote Generator with History

Shows the quote of the day, fetches new random quotes from public APIs, and saves favorites to a SQLite database. Each browser has its own favorites list, with copy-to-clipboard on every quote.

## Features
- Quote of the day and random quotes from public APIs ([ZenQuotes](https://zenquotes.io), with [DummyJSON](https://dummyjson.com/docs/quotes) as backup, and a small built-in list if both are offline)
- Favorites stored in a backend `favorites` table (duplicates ignored)
- Favorites history list with remove button
- Copy to clipboard for the current quote and for each favorite

## Tech stack
Node.js, Express, SQLite (`better-sqlite3`), vanilla HTML/CSS/JS

## Run locally
```bash
npm install
npm start
# open http://localhost:3000
```
`npm test` runs an API test with the external quote API mocked.

## API
| Method | Endpoint | Description |
| --- | --- | --- |
| GET | `/api/quote/today` | Quote of the day (cached per day) |
| GET | `/api/quote/random` | Random quote |
| GET | `/api/favorites` | List the user's favorites |
| POST | `/api/favorites` | Save `{ text, author }` |
| DELETE | `/api/favorites/:id` | Remove a favorite |

Favorites endpoints need an `X-User-Id` header. The frontend generates one per browser and keeps it in `localStorage`.

## Database
```sql
favorites (id, user_id, text, author, created_at, UNIQUE (user_id, text))
```

## Project structure
```
server.js     starts the server
app.js        Express routes
quotes.js     third-party API calls with fallbacks
db.js         SQLite schema and queries
public/       frontend
test.js       API test
```
