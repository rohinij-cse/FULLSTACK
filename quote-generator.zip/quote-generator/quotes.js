// Step 1: fetch quotes from public APIs (server-side, so no browser CORS problems)
const FALLBACK = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "It always seems impossible until it's done.", author: "Nelson Mandela" },
  { text: "Whether you think you can, or you think you can't, you're right.", author: "Henry Ford" },
  { text: "Well done is better than well said.", author: "Benjamin Franklin" },
  { text: "The best way to predict the future is to invent it.", author: "Alan Kay" },
];

async function getJson(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
  if (!res.ok) throw new Error(`${url} responded ${res.status}`);
  return res.json();
}

// Each provider returns { text, author }
const providers = {
  random: [
    async () => {
      const [q] = await getJson("https://zenquotes.io/api/random");
      return { text: q.q, author: q.a };
    },
    async () => {
      const q = await getJson("https://dummyjson.com/quotes/random");
      return { text: q.quote, author: q.author };
    },
  ],
  today: [
    async () => {
      const [q] = await getJson("https://zenquotes.io/api/today");
      return { text: q.q, author: q.a };
    },
  ],
};

async function fromProviders(list) {
  for (const p of list) {
    try {
      const q = await p();
      if (q && q.text) return { ...q, author: q.author || "Unknown", source: "api" };
    } catch (_) { /* try next provider */ }
  }
  return null;
}

const fallbackQuote = (seed) => ({ ...FALLBACK[seed % FALLBACK.length], source: "fallback" });

let dailyCache = { date: null, quote: null };

async function getRandom() {
  return (await fromProviders(providers.random)) || fallbackQuote(Math.floor(Math.random() * 1000));
}

async function getToday() {
  const today = new Date().toISOString().slice(0, 10);
  if (dailyCache.date === today) return dailyCache.quote;
  const day = Math.floor(Date.now() / 86400000);
  const quote = (await fromProviders(providers.today)) || fallbackQuote(day);
  // Only cache real API results, so a failed fetch is retried next time
  if (quote.source === "api") dailyCache = { date: today, quote };
  return quote;
}

module.exports = { getRandom, getToday };
