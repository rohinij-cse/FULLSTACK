const $ = (id) => document.getElementById(id);
const quoteEl = $("quote"), authorEl = $("author"), labelEl = $("label");
const favBtn = $("fav"), newBtn = $("new"), copyBtn = $("copy"), listEl = $("list"), toastEl = $("toast");

// Anonymous per-browser user id so each visitor has their own favorites
let userId = localStorage.getItem("quoteUserId");
if (!userId) {
  userId = (crypto.randomUUID && crypto.randomUUID()) || `u-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  localStorage.setItem("quoteUserId", userId);
}
const headers = { "Content-Type": "application/json", "X-User-Id": userId };

let current = null;     // quote on screen
let favorites = [];     // saved quotes (history)

function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => toastEl.classList.remove("show"), 1800);
}

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const findFav = (q) => favorites.find((f) => q && f.text === q.text);

function renderQuote() {
  quoteEl.textContent = current ? `“${current.text}”` : "Could not load a quote.";
  authorEl.textContent = current ? current.author : "";
  const saved = !!findFav(current);
  favBtn.setAttribute("aria-pressed", String(saved));
  favBtn.textContent = saved ? "Saved" : "Save to favorites";
}

function renderFavorites() {
  if (!favorites.length) {
    listEl.innerHTML = `<li class="empty">No favorites yet. Save a quote and it will show up here.</li>`;
    return;
  }
  listEl.innerHTML = favorites.map((f) => `
    <li data-id="${f.id}">
      <p class="text">“${esc(f.text)}”</p>
      <div class="meta">
        <span><span class="who">${esc(f.author)}</span> · saved ${new Date(f.created_at.replace(" ", "T") + "Z").toLocaleDateString()}</span>
        <span class="row-actions">
          <button class="icon-btn" data-copy="${f.id}">Copy</button>
          <button class="icon-btn" data-remove="${f.id}">Remove</button>
        </span>
      </div>
    </li>`).join("");
}

// Step 4: copy to clipboard (with a fallback for older browsers / non-HTTPS pages)
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
  toast("Copied to clipboard");
}
const formatQuote = (q) => `“${q.text}” — ${q.author}`;

async function fetchQuote(kind) {
  newBtn.disabled = true;
  try {
    const res = await fetch(`/api/quote/${kind}`);
    current = await res.json();
    labelEl.textContent = kind === "today" ? "Quote of the day" : "Random quote";
  } catch {
    current = null;
  } finally {
    newBtn.disabled = false;
    renderQuote();
  }
}

async function loadFavorites() {
  const res = await fetch("/api/favorites", { headers });
  favorites = await res.json();
  renderFavorites();
  renderQuote();
}

// Step 3: favorites history is saved to and rendered from the database
favBtn.addEventListener("click", async () => {
  if (!current) return;
  const existing = findFav(current);
  if (existing) {
    await fetch(`/api/favorites/${existing.id}`, { method: "DELETE", headers });
    toast("Removed from favorites");
  } else {
    await fetch("/api/favorites", { method: "POST", headers, body: JSON.stringify({ text: current.text, author: current.author }) });
    toast("Saved to favorites");
  }
  await loadFavorites();
});

newBtn.addEventListener("click", () => fetchQuote("random"));
copyBtn.addEventListener("click", () => current && copyText(formatQuote(current)));

listEl.addEventListener("click", async (e) => {
  const copyId = e.target.dataset.copy, removeId = e.target.dataset.remove;
  if (copyId) {
    const f = favorites.find((x) => x.id === Number(copyId));
    if (f) copyText(formatQuote(f));
  } else if (removeId) {
    await fetch(`/api/favorites/${removeId}`, { method: "DELETE", headers });
    await loadFavorites();
  }
});

fetchQuote("today").then(loadFavorites);
