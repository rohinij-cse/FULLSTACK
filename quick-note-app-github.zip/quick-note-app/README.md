# Quick Note Application

A simple full-stack note-taking web application built with **Node.js**, **Express.js**, HTML, CSS, and vanilla JavaScript. It demonstrates REST API endpoints, asynchronous frontend requests using `fetch()`, and persistent JSON-file storage.

## Features

- Create notes with a title and content
- View all saved notes
- Delete notes
- Persist notes in `notes.json`
- Responsive layout for desktop and mobile
- Asynchronous requests without full-page reloads
- Basic input validation and API error handling

## Tech Stack

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js, Express.js
- Storage: Local JSON file

## Project Structure

```text
quick-note-app/
├── public/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── notes.json
├── server.js
├── package.json
├── .gitignore
└── README.md
```

## Requirements

- [Node.js](https://nodejs.org/) (includes npm)

## Run Locally

1. Clone the repository or download this project.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open [http://localhost:3000](http://localhost:3000) in your browser.

## REST API

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/notes` | Retrieve all notes |
| `POST` | `/notes` | Create a note |
| `DELETE` | `/notes/:id` | Delete a note by ID |

### Example request body for `POST /notes`

```json
{
  "title": "Project Meeting",
  "content": "Prepare the project presentation."
}
```

## Notes on Storage

Notes are stored in `notes.json`. This is appropriate for a small educational project. For production or concurrent multi-user usage, use a database and stronger concurrency handling.

## Future Improvements

- Edit existing notes (`PUT /notes/:id`)
- Search and filter notes
- Add timestamps and sorting options
- Use a database such as SQLite, PostgreSQL, or MongoDB
- Add authentication for individual users

## License

This project is provided for educational use.
