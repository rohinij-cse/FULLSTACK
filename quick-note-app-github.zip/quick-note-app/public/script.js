const noteForm = document.getElementById("noteForm");
const titleInput = document.getElementById("title");
const contentInput = document.getElementById("content");
const notesContainer = document.getElementById("notesContainer");
const noteCount = document.getElementById("noteCount");
const message = document.getElementById("message");
const submitButton = document.getElementById("submitButton");

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || "Something went wrong. Please try again.");
  }

  return data;
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}

function createNoteCard(note) {
  const card = document.createElement("article");
  card.className = "note-card";

  const title = document.createElement("h3");
  title.textContent = note.title;

  const content = document.createElement("p");
  content.className = "note-content";
  content.textContent = note.content;

  const date = document.createElement("p");
  date.className = "note-date";
  const parsedDate = new Date(note.createdAt);
  date.textContent = Number.isNaN(parsedDate.getTime())
    ? ""
    : `Created ${parsedDate.toLocaleString()}`;

  const deleteButton = document.createElement("button");
  deleteButton.className = "delete-btn";
  deleteButton.type = "button";
  deleteButton.textContent = "Delete note";

  deleteButton.addEventListener("click", async () => {
    if (!window.confirm(`Delete "${note.title}"?`)) return;

    deleteButton.disabled = true;
    try {
      await request(`/notes/${encodeURIComponent(note.id)}`, {
        method: "DELETE"
      });
      showMessage("Note deleted successfully.");
      await loadNotes();
    } catch (error) {
      showMessage(error.message, true);
      deleteButton.disabled = false;
    }
  });

  card.append(title, content, date, deleteButton);
  return card;
}

async function loadNotes() {
  try {
    const notes = await request("/notes");
    notesContainer.replaceChildren();
    noteCount.textContent = String(notes.length);

    if (notes.length === 0) {
      const empty = document.createElement("p");
      empty.className = "empty-state";
      empty.textContent = "No notes yet. Create your first note above.";
      notesContainer.appendChild(empty);
      return;
    }

    notes.forEach(note => notesContainer.appendChild(createNoteCard(note)));
  } catch (error) {
    showMessage(error.message, true);
    notesContainer.replaceChildren();
    const errorText = document.createElement("p");
    errorText.className = "empty-state";
    errorText.textContent = "Notes could not be loaded. Please refresh the page.";
    notesContainer.appendChild(errorText);
  }
}

noteForm.addEventListener("submit", async event => {
  event.preventDefault();

  const title = titleInput.value.trim();
  const content = contentInput.value.trim();

  if (!title || !content) {
    showMessage("Please enter both a title and note content.", true);
    return;
  }

  submitButton.disabled = true;
  submitButton.textContent = "Saving...";

  try {
    await request("/notes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, content })
    });

    noteForm.reset();
    showMessage("Your note has been saved.");
    await loadNotes();
  } catch (error) {
    showMessage(error.message, true);
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = "<span aria-hidden=\"true\">＋</span> Add note";
  }
});

loadNotes();
