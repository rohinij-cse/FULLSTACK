const express = require("express");
const fs = require("fs/promises");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "notes.json");

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

async function readNotes() {
  const data = await fs.readFile(DATA_FILE, "utf8");
  return JSON.parse(data);
}

async function saveNotes(notes) {
  await fs.writeFile(DATA_FILE, JSON.stringify(notes, null, 2), "utf8");
}

// GET /notes - retrieve all notes
app.get("/notes", async (req, res) => {
  try {
    res.json(await readNotes());
  } catch (error) {
    console.error("Could not load notes:", error);
    res.status(500).json({ error: "Could not load notes" });
  }
});

// POST /notes - create a note
app.post("/notes", async (req, res) => {
  try {
    const { title, content } = req.body ?? {};

    if (
      typeof title !== "string" ||
      typeof content !== "string" ||
      !title.trim() ||
      !content.trim()
    ) {
      return res.status(400).json({
        error: "Title and content are required"
      });
    }

    const notes = await readNotes();
    const newNote = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      title: title.trim(),
      content: content.trim(),
      createdAt: new Date().toISOString()
    };

    notes.unshift(newNote);
    await saveNotes(notes);
    res.status(201).json(newNote);
  } catch (error) {
    console.error("Could not save note:", error);
    res.status(500).json({ error: "Could not save note" });
  }
});

// DELETE /notes/:id - delete one note
app.delete("/notes/:id", async (req, res) => {
  try {
    const notes = await readNotes();
    const updatedNotes = notes.filter(note => note.id !== req.params.id);

    if (updatedNotes.length === notes.length) {
      return res.status(404).json({ error: "Note not found" });
    }

    await saveNotes(updatedNotes);
    res.json({ message: "Note deleted successfully" });
  } catch (error) {
    console.error("Could not delete note:", error);
    res.status(500).json({ error: "Could not delete note" });
  }
});

app.listen(PORT, () => {
  console.log(`Quick Note App running at http://localhost:${PORT}`);
});
