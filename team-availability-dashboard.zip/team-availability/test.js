// API smoke test: node test.js
process.env.DB_FILE = ":memory:";
const assert = require("assert");
const app = require("./app");

const server = app.listen(0, async () => {
  const base = `http://localhost:${server.address().port}`;
  const J = { "Content-Type": "application/json" };
  try {
    const members = await (await fetch(`${base}/api/members`)).json();
    assert(members.length >= 3, "seed members present");
    const id = members[0].id;

    const res = await fetch(`${base}/api/members/${id}/status`, { method: "PATCH", headers: J, body: JSON.stringify({ status: "busy" }) });
    const updated = await res.json();
    assert.strictEqual(updated.status, "busy");

    const again = (await (await fetch(`${base}/api/members`)).json()).find((m) => m.id === id);
    assert.strictEqual(again.status, "busy", "status persisted in the database");

    const bad = await fetch(`${base}/api/members/${id}/status`, { method: "PATCH", headers: J, body: JSON.stringify({ status: "sleeping" }) });
    assert.strictEqual(bad.status, 400);
    const missing = await fetch(`${base}/api/members/9999/status`, { method: "PATCH", headers: J, body: JSON.stringify({ status: "away" }) });
    assert.strictEqual(missing.status, 404);

    const added = await fetch(`${base}/api/members`, { method: "POST", headers: J, body: JSON.stringify({ name: "Test User", role: "Tester" }) });
    assert.strictEqual(added.status, 201);

    console.log("All tests passed");
    process.exit(0);
  } catch (e) { console.error(e); process.exit(1); }
});
