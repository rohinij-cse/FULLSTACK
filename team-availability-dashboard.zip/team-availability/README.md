# Team Availability Dashboard

A live dashboard where each team member's status (Available, Busy, Away) can be toggled. Changes are saved in a SQLite database and pushed instantly to every open browser.

## Features
- Relational schema: `members` linked to a `statuses` lookup table
- REST endpoints to update a member's status (validated on the server)
- Responsive card layout with colour-coded badges, status counts and filter chips
- Live updates across all browsers using Server-Sent Events (no refresh needed)
- Add and remove team members

## Tech stack
Node.js, Express, SQLite (`better-sqlite3`), vanilla HTML/CSS/JS

## Run locally
```bash
npm install
npm start
# open http://localhost:3000 in two tabs and toggle a status in one
```
`npm test` runs the API tests.

## API
| Method | Endpoint | Description |
| --- | --- | --- |
| GET | `/api/members` | All members with their current status |
| GET | `/api/statuses` | Allowed statuses |
| PATCH | `/api/members/:id/status` | Body `{ "status": "available" \| "busy" \| "away" }` |
| POST | `/api/members` | Add a member `{ name, role }` |
| DELETE | `/api/members/:id` | Remove a member |
| GET | `/api/stream` | Live event stream of the member list |

## Database schema
```sql
statuses (id, name UNIQUE, label)
members  (id, name, role, status_id -> statuses.id, updated_at)
```

## Project structure
```
server.js   starts the server
app.js      routes + live broadcast
db.js       schema, seed data, queries
public/     frontend
test.js     API tests
```

## Possible improvements
Add login so people can only change their own status, status history log, custom status messages.
