const grid = document.getElementById("grid");
const summary = document.getElementById("summary");
const connEl = document.getElementById("conn");

const STATUSES = [
  { name: "available", label: "Available" },
  { name: "busy", label: "Busy" },
  { name: "away", label: "Away" },
];

let members = [];
let filter = "all";

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const initials = (n) => n.split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();

function ago(iso) {
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso)) / 1000));
  if (s < 10) return "just now";
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

// Step 3: summary chips (counts + filter) and member cards
function renderSummary() {
  const counts = { all: members.length };
  STATUSES.forEach((s) => (counts[s.name] = members.filter((m) => m.status === s.name).length));
  const chips = [{ name: "all", label: "Everyone" }, ...STATUSES];
  summary.innerHTML = chips.map((c) => `
    <button class="chip" data-filter="${c.name}" aria-pressed="${filter === c.name}">
      ${c.name === "all" ? "" : `<span class="dot ${c.name}"></span>`}${c.label} <b>${counts[c.name]}</b>
    </button>`).join("");
}

function renderGrid() {
  const shown = members.filter((m) => filter === "all" || m.status === filter);
  if (!shown.length) {
    grid.innerHTML = `<p class="empty">Nobody is ${filter} right now.</p>`;
    return;
  }
  grid.innerHTML = shown.map((m) => `
    <article class="card ${m.status}" data-id="${m.id}">
      <div class="who">
        <div class="avatar" aria-hidden="true">${esc(initials(m.name))}</div>
        <div><p class="name">${esc(m.name)}</p><p class="role">${esc(m.role)}</p></div>
        <button class="remove" data-remove="${m.id}" aria-label="Remove ${esc(m.name)}" title="Remove">×</button>
      </div>
      <div class="badge-row">
        <span class="badge ${m.status}"><span class="dot ${m.status}"></span>${esc(m.status_label)}</span>
        <span class="since" data-since="${m.updated_at}">${ago(m.updated_at)}</span>
      </div>
      <div class="toggle" role="group" aria-label="Set status for ${esc(m.name)}">
        ${STATUSES.map((s) => `<button data-set="${s.name}" aria-pressed="${m.status === s.name}">${s.label}</button>`).join("")}
      </div>
    </article>`).join("");
}

function render() {
  renderSummary();
  renderGrid();
}

// Toggling sends a PATCH to the backend. The server then pushes the change to every open dashboard.
grid.addEventListener("click", async (e) => {
  const card = e.target.closest(".card");
  if (!card) return;
  const id = card.dataset.id;

  if (e.target.dataset.set) {
    const status = e.target.dataset.set;
    const m = members.find((x) => x.id === Number(id));
    if (!m || m.status === status) return;
    const previous = { ...m };
    Object.assign(m, { status, status_label: STATUSES.find((s) => s.name === status).label, updated_at: new Date().toISOString() });
    render(); // optimistic update so the click feels instant
    const res = await fetch(`/api/members/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    }).catch(() => null);
    if (!res || !res.ok) { Object.assign(m, previous); render(); }
  } else if (e.target.dataset.remove) {
    const m = members.find((x) => x.id === Number(id));
    if (confirm(`Remove ${m.name} from the team?`)) await fetch(`/api/members/${id}`, { method: "DELETE" });
  }
});

summary.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-filter]");
  if (btn) { filter = btn.dataset.filter; render(); }
});

document.getElementById("add").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("add-name");
  const role = document.getElementById("add-role");
  const res = await fetch("/api/members", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: name.value, role: role.value }),
  });
  if (res.ok) { name.value = ""; role.value = ""; name.focus(); }
});

// Live connection (Server-Sent Events). The browser reconnects automatically if it drops.
function connect() {
  const es = new EventSource("/api/stream");
  es.onopen = () => { connEl.textContent = "Live: updates appear instantly"; connEl.classList.add("live"); };
  es.onmessage = (e) => { members = JSON.parse(e.data); render(); };
  es.onerror = () => { connEl.textContent = "Reconnecting…"; connEl.classList.remove("live"); };
}

// Keep the "x minutes ago" labels fresh without re-rendering the cards
setInterval(() => {
  document.querySelectorAll("[data-since]").forEach((el) => (el.textContent = ago(el.dataset.since)));
}, 15000);

connect();
