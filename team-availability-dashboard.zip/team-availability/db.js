const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(process.env.DB_FILE || path.join(__dirname, "team.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// Step 1: schema. `statuses` holds the allowed status flags, `members` points to one of them.
db.exec(`
  CREATE TABLE IF NOT EXISTS statuses (
    id    INTEGER PRIMARY KEY,
    name  TEXT NOT NULL UNIQUE,
    label TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS members (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    role       TEXT NOT NULL,
    status_id  INTEGER NOT NULL DEFAULT 1 REFERENCES statuses(id),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );
`);

const insertStatus = db.prepare("INSERT OR IGNORE INTO statuses (id, name, label) VALUES (?, ?, ?)");
[[1, "available", "Available"], [2, "busy", "Busy"], [3, "away", "Away"]].forEach((s) => insertStatus.run(...s));

if (db.prepare("SELECT COUNT(*) AS n FROM members").get().n === 0) {
  const ins = db.prepare("INSERT INTO members (name, role, status_id) VALUES (?, ?, ?)");
  [
    ["Aarav Mehta", "Team Lead", 1],
    ["Priya Nair", "Frontend Developer", 2],
    ["Karthik Raman", "Backend Developer", 1],
    ["Sneha Iyer", "UI/UX Designer", 3],
    ["Rohan Das", "QA Engineer", 1],
    ["Meera Krishnan", "Data Analyst", 2],
  ].forEach((m) => ins.run(...m));
}

const SELECT = `
  SELECT m.id, m.name, m.role, s.name AS status, s.label AS status_label, m.updated_at
  FROM members m JOIN statuses s ON s.id = m.status_id`;

module.exports = {
  statuses: () => db.prepare("SELECT name, label FROM statuses ORDER BY id").all(),
  members: () => db.prepare(`${SELECT} ORDER BY m.name`).all(),
  member: (id) => db.prepare(`${SELECT} WHERE m.id = ?`).get(id),
  setStatus: (id, status) => {
    const s = db.prepare("SELECT id FROM statuses WHERE name = ?").get(status);
    if (!s) return { error: "invalid_status" };
    const res = db
      .prepare("UPDATE members SET status_id = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?")
      .run(s.id, id);
    return res.changes ? { member: module.exports.member(id) } : { error: "not_found" };
  },
  addMember: (name, role) => {
    const info = db.prepare("INSERT INTO members (name, role) VALUES (?, ?)").run(name, role);
    return module.exports.member(info.lastInsertRowid);
  },
  removeMember: (id) => db.prepare("DELETE FROM members WHERE id = ?").run(id).changes > 0,
};
