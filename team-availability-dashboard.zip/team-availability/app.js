const express = require("express");
const path = require("path");
const db = require("./db");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Step 4: live updates. Every change is pushed to all connected dashboards (Server-Sent Events).
const clients = new Set();
function broadcast() {
  const payload = `data: ${JSON.stringify(db.members())}\n\n`;
  for (const res of clients) res.write(payload);
}

app.get("/api/stream", (req, res) => {
  res.set({ "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
  res.flushHeaders();
  res.write(`data: ${JSON.stringify(db.members())}\n\n`);
  clients.add(res);
  req.on("close", () => clients.delete(res));
});

// Step 2: REST endpoints
app.get("/api/statuses", (req, res) => res.json(db.statuses()));
app.get("/api/members", (req, res) => res.json(db.members()));

app.patch("/api/members/:id/status", (req, res) => {
  const result = db.setStatus(Number(req.params.id), req.body.status);
  if (result.error === "invalid_status")
    return res.status(400).json({ error: "Status must be one of: available, busy, away" });
  if (result.error) return res.status(404).json({ error: "Member not found" });
  broadcast();
  res.json(result.member);
});

app.post("/api/members", (req, res) => {
  const name = String(req.body.name || "").trim();
  const role = String(req.body.role || "").trim();
  if (!name || !role) return res.status(400).json({ error: "Name and role are required" });
  const member = db.addMember(name.slice(0, 80), role.slice(0, 80));
  broadcast();
  res.status(201).json(member);
});

app.delete("/api/members/:id", (req, res) => {
  if (!db.removeMember(Number(req.params.id))) return res.status(404).json({ error: "Member not found" });
  broadcast();
  res.status(204).end();
});

module.exports = app;
